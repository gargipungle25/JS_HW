class Course{
    courseName: string
    courseCode: number
    instructor: string

    constructor ( courseCode: number, courseName: string,instructor: string){
        this.courseCode=courseCode;
        this.courseName=courseName;
        this.instructor=instructor;
    }

    displayInfo():void{
        console.log(this.courseCode+" ",this.courseName+" ",this.instructor);
    }
}

const c1=new Course(1,"CMPN","PR")
const c2=new Course(2,"INFT","SS")
const c3=new Course(3,"EXTC","KN")
const c4=new Course(4,"ELEC","AA")

c1.displayInfo();
c2.displayInfo();
c3.displayInfo();
c4.displayInfo();