var Student = /** @class */ (function () {
    function Student() {
        this.name = "Gargi";
        this.studentId = 2;
        this.grade = "A";
        this.address = "SFIT hostel";
    }
    Student.prototype.displayInfo = function () {
        console.log(this.name + " ", this.studentId + " ", this.grade + " ", this.address);
    };
    return Student;
}());
var s = new Student();
s.displayInfo();
