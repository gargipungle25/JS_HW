class Student{
    name: string="Gargi"
    studentId: number=2
    grade:string="A"
    address:string="SFIT hostel"
    displayInfo():void{
        console.log(this.name+" ",this.studentId+" ",this.grade+" ",this.address);
        
    }
}
const  s = new Student();
s.displayInfo();