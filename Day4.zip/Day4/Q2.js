var Student = /** @class */ (function () {
    function Student(name, id) {
        this.name = name;
        this.id = id;
    }
    Student.prototype.displayInfo = function () {
        console.log(this.name + " ", this.id);
    };
    return Student;
}());
var School = /** @class */ (function () {
    function School() {
        this.studentList = [];
    }
    School.prototype.studentCount = function () {
        console.log(School.totalStudent);
        console.log(this.studentList);
    };
    School.prototype.addStudent = function (st) {
        this.studentList.push(st);
        School.totalStudent++;
    };
    School.totalStudent = 0;
    return School;
}());
var s1 = new Student("gargi", 1);
var s2 = new Student("Valeska", 2);
var s3 = new Student("valentina", 3);
var s4 = new Student("Ishika", 4);
var sc = new School();
sc.addStudent(s1);
sc.addStudent(s2);
sc.addStudent(s3);
sc.addStudent(s4);
sc.studentCount();
