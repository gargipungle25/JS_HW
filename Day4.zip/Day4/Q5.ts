//Create an interface Attendance with method markAttendance(). Implement this interface in student class and define how attendance is marked for attendance 



interface Attendance{
   markAttendance(): void;
}

class Student implements Attendance{
    name: string
    id:  number
    isPresent: boolean   = false

    constructor(name: string, id: number, isPresent: boolean){
        this.name=name;
        this.id=id;
        this.isPresent=isPresent;
    }
    markAttendance(): void {
        // this.isPresent=true;
        console.log(this.name+" ",this.id);
        
    }

    displayStatus(): void{
        const status= this.isPresent ? "P":"A"
        console.log(status);
        
    }
}

const s1= new Student("Gargi",1,true);
const s2=new Student("Valeska", 2,false);

s1.markAttendance()
s2.markAttendance()
s1.displayStatus()
s2.displayStatus()