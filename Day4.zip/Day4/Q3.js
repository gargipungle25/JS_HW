var Course = /** @class */ (function () {
    function Course(courseCode, courseName, instructor) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.instructor = instructor;
    }
    Course.prototype.displayInfo = function () {
        console.log(this.courseCode + " ", this.courseName + " ", this.instructor);
    };
    return Course;
}());
var c1 = new Course(1, "CMPN", "PR");
var c2 = new Course(2, "INFT", "SS");
var c3 = new Course(3, "EXTC", "KN");
var c4 = new Course(4, "ELEC", "AA");
c1.displayInfo();
c2.displayInfo();
c3.displayInfo();
c4.displayInfo();
