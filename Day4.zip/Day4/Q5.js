//Create an interface Attendance with method markAttendance(). Implement this interface in student class and define how attendance is marked for attendance 
var Student = /** @class */ (function () {
    function Student(name, id, isPresent) {
        this.isPresent = false;
        this.name = name;
        this.id = id;
        this.isPresent = isPresent;
    }
    Student.prototype.markAttendance = function () {
        // this.isPresent=true;
        console.log(this.name + " ", this.id);
    };
    Student.prototype.displayStatus = function () {
        var status = this.isPresent ? "P" : "A";
        console.log(status);
    };
    return Student;
}());
var s1 = new Student("Gargi", 1, true);
var s2 = new Student("Valeska", 2, false);
s1.markAttendance();
s2.markAttendance();
s1.displayStatus();
s2.displayStatus();
