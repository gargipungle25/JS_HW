class Student{
    name:  string
    id: number

    constructor(name: string, id: number){
        this.name=name
        this.id=id
    }

    displayInfo(): void{
        console.log(this.name+" ",this.id);
    }
}

class School{
    static totalStudent: number=0
    studentList: any = []

    studentCount(): void{
        console.log(School.totalStudent);
        console.log(this.studentList);
        
    }

    addStudent(st: Student): void{
        this.studentList.push(st);
        School.totalStudent++
    }
}

const s1= new Student("gargi",1)
const s2= new Student("Valeska",2)
const s3= new Student("valentina",3)
const s4= new Student("Ishika",4)

const sc=new School();

sc.addStudent(s1)
sc.addStudent(s2)
sc.addStudent(s3)
sc.addStudent(s4)

sc.studentCount()
