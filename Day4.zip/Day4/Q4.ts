abstract class Person{
    abstract getDetails(): void
    abstract getRole(): string
}

class Student extends Person {
    name: string
    id: number

    constructor (name: string, id: number){
        super()
        this.name=name
        this.id=id
    }

    getDetails(): void {
        console.log(this.name+" ", this.id);
    }

    getRole(): string {
        return "Student"
    }

}

class Teacher extends Person{
    name: string
    subject: string

    constructor(name: string, subject: string){
        super()
        this.name=name
        this.subject=subject
    }

    getDetails(): void {
        console.log(this.name+" ", this.subject);
    }
    getRole(): string {
        return "Teacher"
    }
}

const st= new Student("Gargi", 1)
const st1=new Student("Valentina",2)
const st2=new Student("Valeska",3)
const st3=new Student("Ishika",4)

st.getDetails()
st1.getDetails()
st2.getDetails()
st3.getDetails()
console.log(st.getRole());
console.log(st1.getRole());
console.log(st2.getRole());
console.log(st3.getRole());

const t1= new Teacher("Ajay","JAVA")
const t2= new Teacher("Sanjay", "JS")

t1.getDetails()
t2.getDetails()
console.log(t1.getRole());
console.log(t2.getRole());
