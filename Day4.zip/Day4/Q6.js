function displayInfo(data) {
    return data;
}
console.log(displayInfo(100));
console.log(displayInfo("Gargi"));
console.log(displayInfo(true));
